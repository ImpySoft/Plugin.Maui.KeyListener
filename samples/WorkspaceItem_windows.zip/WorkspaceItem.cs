namespace Fmr.MdiLibrary.Workspace;

#nullable enable
using System.Diagnostics.CodeAnalysis;
using Fmr.LayoutEngine;
using Fmr.MdiLibrary.FeatureFlags;
using Fmr.MdiLibrary.Mouse;
using Fmr.NovaUI.Extensions;
using Fmr.Sirius.Accessors;
using Fmr.Sirius.Maui.Interfaces;

[ExcludeFromCodeCoverage(Justification = "UI Element")]
[ContentProperty(nameof(Content))]
public partial class WorkspaceItem : TemplatedView, IWorkspaceItem, IFocusLoop
{
    private const string PartGrid = "PART_Grid";
    private const string PartDetectionOverlay = "PART_DetectionOverlay";
    public static bool IsAccessibilityEnhancementsEnabled => FeatureFlagAccessor.IsEnabled<AccessibilityEnhancementsFeatureFlag>();

    internal static readonly BindableProperty IsTopProperty =
        BindableProperty.Create(nameof(IsTop), typeof(bool), typeof(WorkspaceItem), false, propertyChanged: OnIsTopChanged);

    public static readonly BindableProperty HeaderProperty =
        BindableProperty.Create(nameof(Header), typeof(object), typeof(WorkspaceItem));

    public static readonly BindableProperty ContentProperty =
        BindableProperty.Create(nameof(Content), typeof(View), typeof(WorkspaceItem));

    public static readonly BindableProperty IsMaximizedProperty =
        BindableProperty.Create(nameof(IsMaximized),
                                typeof(bool),
                                typeof(WorkspaceItem),
                                false,
                                BindingMode.TwoWay,
                                propertyChanging: OnIsMaximizedChanging,
                                propertyChanged: OnIsMaximizedChanged);

    private static readonly BindableProperty IsMagnetizedProperty =
        BindableProperty.Create(nameof(IsMagnetized), typeof(bool), typeof(WorkspaceItem), false, BindingMode.TwoWay, propertyChanged: OnIsMagnetizedChanged);

    private VisualElement? _layout;
    private InputDetectionOverlay? _overlay;

    private bool _disposed;

    internal event EventHandler<RaiseTopRequestedEventArgs>? RaiseTopRequested;

    internal event EventHandler<WorkspaceItemPressedEventArgs>? Pressed;

    /// <summary>
    /// Event raised when a change occurs in the position of an item
    /// </summary>
    public event EventHandler<BoundsChangedEventArgs>? BoundsChanged;

    /// <summary>
    /// Event raised when a change occurs in the ZIndex of an item
    /// </summary>
    public event EventHandler? ZIndexChanged;

    public event EventHandler? IsMaximizedChanged;

    /// <summary>
    /// Event raised when a change occurs in the Magnetize of an item
    /// </summary>
    public event EventHandler? IsMagnetizedChanged;

    public event EventHandler? IsMaximizedChanging;

    public bool IsSnap { get; set; }

    public bool IsResizeSnap { get; set; }

    public View? FirstFocusElement { get; set; }

    private View? _lastFocusElement;

    public View? LastFocusElement
    {
        get => _lastFocusElement;
        set
        {
            if (_lastFocusElement != null)
            {
                _lastFocusElement.Unfocused -= OnLastElementLostFocus;
            }

            _lastFocusElement = value;

            if (_lastFocusElement != null)
            {
                _lastFocusElement.Unfocused += OnLastElementLostFocus;
            }
        }
    }

    /// <summary>
    /// CanResizeHorizontally indicate if tool window can resize horizontally
    /// </summary>
    public bool CanResizeHorizontally { get; set; }

    /// <summary>
    /// CanResizeVertically indicate if tool window can resize vertically
    /// </summary>
    public bool CanResizeVertically { get; set; }

    public double MaximumWidth => ((IView)this).MaximumWidth;
    public double MaximumHeight => ((IView)this).MaximumHeight;

    public bool IsTop
    {
        get => (bool)GetValue(IsTopProperty);
        set => SetValue(IsTopProperty, value);
    }

    public bool IsToolWindowFocus => IsAccessibilityEnhancementsEnabled;

    internal bool CanReceiveInput { get; set; }

    public object Header
    {
        get => GetValue(HeaderProperty);
        set => SetValue(HeaderProperty, value);
    }

    public View Content
    {
        get => (View)GetValue(ContentProperty);
        set => SetValue(ContentProperty, value);
    }

    public bool CanMaximize =>
        CanResizeHorizontally &&
        CanResizeVertically &&
        MaximumWidth == double.PositiveInfinity &&
        MaximumHeight == double.PositiveInfinity;

    public bool IsMaximized
    {
        get => (bool)GetValue(IsMaximizedProperty);
        set => SetValue(IsMaximizedProperty, value);
    }

    public bool IsMagnetized
    {
        get => (bool)GetValue(IsMagnetizedProperty);
        set => SetValue(IsMagnetizedProperty, value);
    }

    private static void OnIsMaximizedChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is WorkspaceItem workspaceItem && oldValue != newValue)
        {
            workspaceItem.IsMaximizedChanged?.Invoke(workspaceItem, EventArgs.Empty);
        }
    }

    private static void OnIsMagnetizedChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is WorkspaceItem workspaceItem && oldValue != newValue)
        {
            workspaceItem.IsMagnetizedChanged?.Invoke(workspaceItem, EventArgs.Empty);
        }
    }

    private static void OnIsMaximizedChanging(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is WorkspaceItem workspaceItem && oldValue != newValue)
        {
            workspaceItem.IsMaximizedChanging?.Invoke(workspaceItem, EventArgs.Empty);
        }
    }

    private static void OnIsTopChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is WorkspaceItem workspaceItem &&
            oldValue != newValue &&
            (bool)newValue &&
            IsAccessibilityEnhancementsEnabled)
        {
            workspaceItem.SetFirstFocus();
        }
    }

    /// <summary>
    /// Set focus to the first focus element if it is defined
    /// </summary>
    public void SetFirstFocus()
    {
        if (IsTop && IsAccessibilityEnhancementsEnabled)
        {
            FirstFocusElement?.Focus();
        }
        else
        {
            //Without a first element to focus on, set focus to the work item itself so the first tab stop is available with only
            //one tab press.
            Focus();
        }
    }

    private static void OnLastElementLostFocus(object? sender, FocusEventArgs e)
    {
        if (sender is VisualElement visualElement &&
            IsAccessibilityEnhancementsEnabled &&
            visualElement.FindParent<WorkspaceItem>() is WorkspaceItem workspaceItem)
        {
            workspaceItem.FirstFocusElement?.Focus();
        }
    }

    /// <summary>
    /// Represents the sizes of the corners and edges of an MDI window
    /// </summary>
    internal GestureLocationEdgeThresholds PointerThresholds { get; set; } = GestureLocationEdgeThresholds.Create(10, 10, 50);

    static WorkspaceItem()
    {
        Generic.EnsureRegistered();
    }

    public WorkspaceItem()
    {
        Unloaded += OnUnloaded;
    }

    private void OnUnloaded(object? sender, EventArgs e)
    {
        Unloaded -= OnUnloaded;
        if (_lastFocusElement != null)
        {
            _lastFocusElement.Unfocused -= OnLastElementLostFocus;
        }
    }

    protected override void OnApplyTemplate()
    {
        base.OnApplyTemplate();

        _layout = GetTemplateChild(PartGrid) as VisualElement;

        if (_layout == null)
        {
            throw new InvalidOperationException($"Templated part {PartGrid} could not be resolved as a {nameof(VisualElement)}");
        }

        _overlay = GetTemplateChild(PartDetectionOverlay) as InputDetectionOverlay;

        if (_overlay == null)
        {
            throw new InvalidOperationException($"Templated part {PartDetectionOverlay} could not be resolved as an {nameof(InputDetectionOverlay)}");
        }

        PointerThresholds = Workspace.GetItemSurfaceThresholds(_layout);
    }

    protected override void OnHandlerChanging(HandlerChangingEventArgs args)
    {
        base.OnHandlerChanging(args);

        if (Handler != null)
        {
            UnsubscribeHandlers();
        }
    }

    protected override void OnHandlerChanged()
    {
        base.OnHandlerChanged();

        if (Handler != null)
        {
            SubscribeHandlers();
        }
#if MACCATALYST
        (Handler.PlatformView as UIKit.UIView).BackgroundColor = UIKit.UIColor.Clear;
#elif WINDOWS
        (Handler.PlatformView as Microsoft.Maui.Platform.ContentPanel).Background =
 new Microsoft.UI.Xaml.Media.SolidColorBrush(Microsoft.UI.Colors.Transparent);
#endif
    }

    private void SubscribeHandlers()
    {
        _overlay!.InputDetected += OverlayInputDetected;
        SubscribeNativeHandlers();
    }

    private void UnsubscribeHandlers()
    {
        if (_overlay != null)
        {
            _overlay.InputDetected -= OverlayInputDetected;
        }
        UnsubscribeNativeHandlers();
    }

    partial void SubscribeNativeHandlers();

    partial void UnsubscribeNativeHandlers();

    partial void SetGestureInput(bool enabled);

    public void SetGestureInputLocation(bool enabled)
    {
        SetGestureInput(enabled);
    }

    private void OverlayInputDetected(object? sender, EventArgs e)
    {
        DispatchRaiseTopRequested(false);
    }

    private void DispatchRaiseTopRequested(bool overrideRaiseToTop)
    {
        if (!IsTop)
        {
            RaiseTopRequested?.Invoke(this, new RaiseTopRequestedEventArgs { OverrideRaiseToTop = overrideRaiseToTop });
        }
    }

    /// <summary>
    /// Event raised when a change occurs in the bounds of an item
    /// </summary>
    public void OnBoundsChanged(Rect bounds)
    {
        BoundsChanged?.Invoke(this, new BoundsChangedEventArgs { Bounds = bounds });
    }

    /// <summary>
    /// Event raised when a change occurs in the ZIndex of an item
    /// </summary>
    public void OnZIndexChanged()
    {
        ZIndexChanged?.Invoke(this, EventArgs.Empty);
    }

    private void RaisePointerActioned(WorkspacePointerPressAction action, Point position, Point offset)
    {
        Pressed?.Invoke(this, new WorkspaceItemPressedEventArgs { Action = action, Position = position, Offset = offset });
    }

    #region IDisposable

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            UnsubscribeHandlers();
            BindingContext = null;

            _disposed = true;
        }
    }

    ~WorkspaceItem()
    {
        Dispose(false);
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    #endregion IDisposable
}
