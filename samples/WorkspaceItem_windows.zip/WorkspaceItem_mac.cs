namespace Fmr.MdiLibrary.Workspace;

#nullable enable
using CoreGraphics;
using Fmr.Sirius.Maui.View;
using UIKit;

public partial class WorkspaceItem
{
    private WorkspaceItemGestureRecognizer? _gestureRecognizer;

    private UITapGestureRecognizer? _headerTap;
    private UIView? _headerContentPlatformView;
    private View? _headerContent;

    partial void SubscribeNativeHandlers()
    {
        _gestureRecognizer?.Dispose();
        _gestureRecognizer = new(HandlePointerAction, this);

        (Handler?.PlatformView as UIView)?.AddGestureRecognizer(_gestureRecognizer);
        AddDoubleClickToMaximize();
    }

    partial void UnsubscribeNativeHandlers()
    {
        if (Handler?.PlatformView is UIView nativeView &&
            nativeView.GestureRecognizers?.Any(x => ReferenceEquals(x, _gestureRecognizer)) == true)
        {
            nativeView.RemoveGestureRecognizer(_gestureRecognizer!);
        }

        _gestureRecognizer?.Dispose();
        _gestureRecognizer = null;
    }

    partial void SetGestureInput(bool enabled) => _gestureRecognizer!.Enabled = enabled;

    private void HandlePointerAction(WorkspacePointerPressAction action, UITouch touch)
    {
        // Position = touch relative to parent view
        // Offset = touch relative to this view
        UIView? parent = Parent?.Handler?.PlatformView as UIView;
        Rect bounds = AbsoluteLayout.GetLayoutBounds(this);
        UIView? child = Handler?.PlatformView as UIView;

        CGPoint position = touch.LocationInView(parent);
        CGPoint offset = touch.LocationInView(child);

        double adjustedY = (child?.Frame.Top ?? 0) - bounds.Top;

        RaisePointerActioned(action, new Point(position.X, position.Y - adjustedY), new Point(offset.X, offset.Y));
    }

    private void OnHeaderDoubleTap(UITapGestureRecognizer sender)
    {
        if (!sender.IsTappedViewInteractable())
        {
            // if what we double-tapped on is not interactable, then toggle the maximized state
            IsMaximized ^= true;
        }
    }

    private void AddDoubleClickToMaximize()
    {
        // do nothing if the tool cannot be maximized
        // and also ensure we have a tool header we can use
        if (!CanMaximize ||
            (Header as ToolHeader)?.ToolHeaderContent is not View headerContent ||
            headerContent?.Handler?.PlatformView is not UIView headerContentPlatformView)
        {
            return;
        }

        _headerContent = headerContent;
        _headerContentPlatformView = headerContentPlatformView;

        // wire up a double-tap recognizer for the tool header
        _headerTap = new(OnHeaderDoubleTap) { NumberOfTapsRequired = 2 };
        headerContentPlatformView.AddGestureRecognizer(_headerTap);
        headerContent.Unloaded += OnHeaderUnloaded;
    }

    private void OnHeaderUnloaded(object? sender, EventArgs e)
    {
        _headerContent!.Unloaded -= OnHeaderUnloaded;
        _headerContentPlatformView!.RemoveGestureRecognizer(_headerTap!);
        _headerTap!.Dispose();
    }
}
