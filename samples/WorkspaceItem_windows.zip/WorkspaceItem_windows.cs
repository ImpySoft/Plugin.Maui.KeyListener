namespace Fmr.MdiLibrary.Workspace;

#nullable enable

using System.Runtime.InteropServices;
using Fmr.MdiLibrary.Mouse;
using Fmr.MdiLibrary.Workspace;
using Fmr.Sirius.Maui.View;
using Microsoft.UI.Input;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;

public partial class WorkspaceItem
{
    private UIElement? _headerContentPlatformView;
    private View? _headerContent;

    partial void SubscribeNativeHandlers()
    {
        if (Handler?.PlatformView is FrameworkElement element)
        {
            element.AddHandler(UIElement.PointerReleasedEvent, (PointerEventHandler)BringToFront, true);
            element.PointerPressed += PointerPressed;
            element.PointerReleased += PointerReleased;
        }

        AddDoubleClickToMaximize();
        //(_closeButton.Handler.PlatformView as Microsoft.UI.Xaml.Controls.Button).UseSystemFocusVisuals = false; // TODO: Handle in XAML
    }

    partial void UnsubscribeNativeHandlers()
    {
        if (Handler.PlatformView is FrameworkElement element)
        {
            //TODO - this sometimes throws an exception that the object was already disposed.  This handles the exception but root cause of why is still unknown
            try
            {
                element.RemoveHandler(UIElement.PointerReleasedEvent, (PointerEventHandler)BringToFront);
            }
            catch (Exception e) when (e is COMException or ObjectDisposedException) { }

            element.PointerPressed -= PointerPressed;
            element.PointerReleased -= PointerReleased;
        }
    }

    private void AddDoubleClickToMaximize()
    {
        // do nothing if the tool cannot be maximized
        if (!CanMaximize ||
            (Header as ToolHeader)?.ToolHeaderContent is not View headerContent ||
            headerContent?.Handler?.PlatformView is not UIElement headerContentPlatformView)
        {
            return;
        }

        _headerContent = headerContent;
        _headerContentPlatformView = headerContentPlatformView;

        // add the double click handler
        _headerContentPlatformView.IsDoubleTapEnabled = true;
        _headerContentPlatformView.DoubleTapped += OnHeaderDoubleTap;
        headerContent.Unloaded += OnHeaderUnloaded;
    }


    private void OnHeaderUnloaded(object? sender, EventArgs e)
    {
        // remove the double click handler
        _headerContentPlatformView!.DoubleTapped -= OnHeaderDoubleTap;
        _headerContent!.Unloaded -= OnHeaderUnloaded;
    }

    private void OnHeaderDoubleTap(object sender, DoubleTappedRoutedEventArgs e)
    {
        if (!SkipPointerEvents(PointerGestureLocation.TopExtended, e.OriginalSource as DependencyObject))
        {
            // if what we double-tapped on is not interactable, then toggle the maximized state
            IsMaximized ^= true;
        }
    }

    partial void SetGestureInput(bool enabled) { }

    private void PointerPressed(object sender, PointerRoutedEventArgs e)
    {
        PointerPoint offsetPointer = e.GetCurrentPoint(Handler.PlatformView as FrameworkElement);
        Point offset = new(offsetPointer.Position.X, offsetPointer.Position.Y);
        PointerGestureLocation gestureLocation = this.GetPointerGestureLocation(offset, PointerThresholds);

        if (SkipPointerEvents(gestureLocation, e.OriginalSource as DependencyObject))
        {
            return;
        }

        if (gestureLocation != PointerGestureLocation.Center)
        {
            (sender as UIElement).CapturePointer(e.Pointer);
        }

        PointerPoint point = e.GetCurrentPoint(Parent.Handler.PlatformView as FrameworkElement);
        RaisePointerActioned(WorkspacePointerPressAction.Activated, new Point(point.Position.X, point.Position.Y), offset);
    }

    private void PointerReleased(object sender, PointerRoutedEventArgs e)
    {
        PointerPoint offsetPointer = e.GetCurrentPoint(Handler.PlatformView as FrameworkElement);
        Point offset = new(offsetPointer.Position.X, offsetPointer.Position.Y);
        PointerGestureLocation gestureLocation = this.GetPointerGestureLocation(offset, PointerThresholds);

        if (gestureLocation != PointerGestureLocation.Center)
        {
            (sender as UIElement).ReleasePointerCapture(e.Pointer);
        }

        PointerPoint point = e.GetCurrentPoint(Parent.Handler.PlatformView as FrameworkElement);
        RaisePointerActioned(WorkspacePointerPressAction.Deactived,
                             new Point(point.Position.X, point.Position.Y),
                             offset);
    }

    /// <summary>
    /// Event handler for AddHandler's PointerReleasedEvent.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void BringToFront(object sender, PointerRoutedEventArgs e)
    {
        DispatchRaiseTopRequested(true);
    }

    /// <summary>
    /// Dinesh - Workaround The clickable region is checked to see if it is a tool header using this method
    /// </summary>
    /// <param name="gestureLocation"> What part of the tool was clicked </param>
    /// <param name="originalSource"> Should be <see cref="RoutedEventArgs.OriginalSource"/> </param>
    /// <returns></returns>
    private bool SkipPointerEvents(PointerGestureLocation gestureLocation, DependencyObject? originalSource)
    {

        bool skipEvent = gestureLocation == PointerGestureLocation.TopExtended &&
                         originalSource is not null &&
                         GetParents(originalSource).OfType<UIElement>().Any(uiElement => uiElement.IsTabStop);
        return skipEvent;
    }

    private IEnumerable<DependencyObject> GetParents(DependencyObject? obj)
    {
        while (obj != null && obj != (DependencyObject?)Handler?.PlatformView)
        {
            yield return obj;
            obj = VisualTreeHelper.GetParent(obj);
        }
    }
}
